# YesNo-Speech-Recognition-FFT
A real time system which records user's voice and detects whether the user said Yes, No, or neither.

This is a university project for Signal Processing course in IUST.
